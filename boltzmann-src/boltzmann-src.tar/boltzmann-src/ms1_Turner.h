int McGetZB(int i, int j, char sequence[MAXSIZE], double **ZM1, double **ZM, double **ZB);
int McGetZM1(int i, int j, char sequence[MAXSIZE], double **ZM1, double **ZB);
int McGetZM(int i, int j, char sequence[MAXSIZE],double **ZM1, double **ZM);
int McGetZ(int i, int j, char sequence[MAXSIZE],double **Z,double **ZB);
double** runMcCaskill(char sequence[MAXSIZE]);

