#define FILENAMELENGTH 100  /*upper bound on num char in file name */
#define MAXSIZE 1300         /*upper bound on num char in RNA sequence */
#define SHAPELENGTH 4*MAXSIZE/7 /*upper bound on num char in the shape*/
#define PRIVATE static
#define min(a, b)  (((a) < (b)) ? (a) : (b))
#define max(a, b)  (((a) > (b)) ? (a) : (b))
double kT;
double ML_base;
double ML_close;
int seqlen;
short *S0;


